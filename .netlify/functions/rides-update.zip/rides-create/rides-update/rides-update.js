"use strict";

// rides-create/rides-update/rides-update.mjs
exports.handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "PATCH" && event.httpMethod !== "PUT") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "M\xE9todo no permitido" })
    };
  }
  try {
    const pathParts = event.path.split("/");
    const rideId = pathParts[pathParts.length - 1];
    if (!rideId || rideId === "rides-update") {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "ID de viaje no proporcionado en la URL" })
      };
    }
    const { status, conductora_nombre, conductora_lat, conductora_lng } = JSON.parse(event.body);
    global.rides = global.rides || [];
    const rideIndex = global.rides.findIndex((ride) => ride.id === rideId);
    if (rideIndex === -1) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ error: "Viaje no encontrado" })
      };
    }
    global.rides[rideIndex] = {
      ...global.rides[rideIndex],
      status,
      conductora: status === "accepted" ? {
        nombre: conductora_nombre,
        lat: parseFloat(conductora_lat),
        lng: parseFloat(conductora_lng)
      } : global.rides[rideIndex].conductora,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    console.log("Viaje actualizado:", global.rides[rideIndex]);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        ride: global.rides[rideIndex],
        message: "Viaje actualizado exitosamente"
      })
    };
  } catch (error) {
    console.error("Error en rides-update:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Error interno del servidor",
        details: error.message
      })
    };
  }
};
