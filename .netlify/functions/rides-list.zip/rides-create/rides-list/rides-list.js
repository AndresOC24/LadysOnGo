"use strict";

// rides-create/rides-list/rides-list.mjs
exports.handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "M\xE9todo no permitido" })
    };
  }
  try {
    const { status = "pending" } = event.queryStringParameters || {};
    global.rides = global.rides || [];
    const filteredRides = global.rides.filter((ride) => ride.status === status);
    console.log(`Listando ${filteredRides.length} viajes con status: ${status}`);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        rides: filteredRides,
        total: filteredRides.length,
        status
      })
    };
  } catch (error) {
    console.error("Error en rides-list:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Error interno del servidor",
        details: error.message
      })
    };
  }
};
