"use strict";

// rides-create/hello-world/hello-world.mjs
global.rides = global.rides || [];
exports.handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "M\xE9todo no permitido" })
    };
  }
  try {
    const { lat, lng, destino, pasajera_nombre } = JSON.parse(event.body);
    if (!lat || !lng || !destino || !pasajera_nombre) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: "Faltan datos: lat, lng, destino, pasajera_nombre son requeridos"
        })
      };
    }
    const rideId = `ride_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const newRide = {
      id: rideId,
      pasajera: {
        nombre: pasajera_nombre,
        lat: parseFloat(lat),
        lng: parseFloat(lng)
      },
      destino,
      status: "pending",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      conductora: null
    };
    global.rides.push(newRide);
    console.log("Nuevo viaje creado:", newRide);
    return {
      statusCode: 201,
      headers,
      body: JSON.stringify({
        success: true,
        ride: newRide,
        message: "Viaje solicitado exitosamente"
      })
    };
  } catch (error) {
    console.error("Error en rides-create:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Error interno del servidor",
        details: error.message
      })
    };
  }
};
